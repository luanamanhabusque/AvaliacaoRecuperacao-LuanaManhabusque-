<?php

	$nome = $_POST["ajax_nome"];
	$sobrenome = $_POST["ajax_sobrenome"];
	$email = $_POST["ajax_email"];
	$matricula = $_POST["ajax_matricula"];
	$usuario = $_POST["ajax_usuario"];
	$senha = $_POST["ajax_senha"];
	$confirmars = $_POST["ajax_confirmars"];


	$xml = new DOMDocument("1.0");

	$dados = $xml->createElement("dados");

	$xml_nome = $xml->createElement("nome", $nome);
	$xml_sobrenome = $xml->createElement("sobrenome", $sobrenome);
	$xml_email = $xml->createElement("email", $email);
	$xml_matricula = $xml->createElement("matricula", $matricula);
	$xml_usuario = $xml->createElement("usuario", $usuario);
	$xml_senha = $xml->createElement("senha", $senha);
	$xml_confirmars = $xml->createElement("confirmars", $confirmars);

	$dados->appendChild($xml_nome);
	$dados->appendChild($xml_sobrenome);
	$dados->appendChild($xml_email);
	$dados->appendChild($xml_matricula);
	$dados->appendChild($xml_usuario);
	$dados->appendChild($xml_senha);
	$dados->appendChild($xml_confirmars);

	$xml->appendChild($dados);

    $xml->save("dados.xml");

    echo json_encode("Xml criado com sucesso");
    
?>