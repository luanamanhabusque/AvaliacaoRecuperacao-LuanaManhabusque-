

$(document).ready(function () {

    $("#bSalvar").click(function () {

        var nome = $("#tNome").val();
        var sobrenome = $("#tSobrenome").val();
        var email = $("#tEmail").val();
        var matricula = $("#tMatricula").val();
        var usuario = $("#tUsuario").val();
        var senha = $("#tSenha").val();
        var confirmars = $("#tConfirmars").val();

        $.ajax({
            type: "POST",
            dataType: "json",
            url: "php/salvar.php",
            data: {
                ajax_nome: nome,
                ajax_sobrenome: sobrenome,
                ajax_email: email,
                ajax_matricula: matricula,
                ajax_usuario: usuario,
                ajax_senha: senha,
                ajax_confirmars: confirmars

            },
            success: function (retorno) {
                alert(retorno);
            }

        });
        (function () {

            $('#tNome').change(function () {
                $('#tNome').val(nome);
            });

            $('#tSobrenome').change(function () {

                $('#tSobrenome').val(sobrenome);
            });

            $('#tEmail').change(function () {

                $('#tEmail').val(email);
            });
            $('#tMatricula').change(function () {

                $('#tMatricula').val(matricula);
            });
            $('#tUsuario').change(function () {

                $('#tUsuario').val(usuario);
            });
            $('#tSenha').change(function () {

                $('#tSenha').val(senha);
            });
            $('#tConfirmars').change(function () {

                $('#tConfirmars').val(confirmars);
            });
        });


    });

});